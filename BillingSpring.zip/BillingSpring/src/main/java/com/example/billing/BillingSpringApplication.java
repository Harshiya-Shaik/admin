package com.example.billing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BillingSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(BillingSpringApplication.class, args);
	}

}
