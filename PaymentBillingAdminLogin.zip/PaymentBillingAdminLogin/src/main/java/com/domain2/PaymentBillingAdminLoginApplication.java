package com.domain2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//import org.springframework.context.annotation.ComponentScan;


@SpringBootApplication
//@ComponentScan("com.domain2")
public class PaymentBillingAdminLoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaymentBillingAdminLoginApplication.class, args);
	}

}
